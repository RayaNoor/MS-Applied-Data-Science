#!/usr/bin/env python
# coding: utf-8

# In[4]:


# SEMI-STRUCTURED DATA PROCESSING

# This program reads in JSON formatted data from a MongoDB collection.
# This is in a format that is structured with lines of data representing one Tweet for Twitter.
# This program contains the data as lists of JSON structures, which are just Python dictionaries and lists.

# START MONGODB
# brew services start mongodb-community@4.4

# SCRAPE TWEETS 
# !python run_twitter_simple_search_save.py "#ClimateSolutions" 500 climate climatesolutions
# !python run_twitter_simple_search_save.py "#ClimatePolicy" 500 climate climatesolutions

# STOP MONGODB
# brew services stop mongodb-community@4.4


# In[5]:


import pymongo
client = pymongo.MongoClient('localhost', 27017)

db = client.climate

db.list_collection_names()


# In[6]:


collection = db.climatesolutions

tweets = collection.find()

tweetlist = [tweet for tweet in tweets]
len(tweetlist) # as of 05/28/2021


# In[7]:


# Here is a little print function that will help.

def print_tweet_data(tweets):
   for tweet in tweets:
       print('\nDate:', tweet['created_at'])
       print('From:', tweet['user']['name'])
       print('Message:', tweet['full_text'])
       if not tweet['place'] is None:
           print('Place:', tweet['place']['full_name'])

print_tweet_data(tweetlist[:5])


# In[ ]:


# https://docs.mongodb.com/database-tools/mongoexport/#examples


# In[8]:


# My program contains pandas dataframes for processed data.

# This program does some processing to collect data from some of the fields the questions described below, 
# and write a file with the data suitable for answering each question.

import numpy as np
import pandas as pd

df = pd.DataFrame(tweetlist)

# Test for null values and remove optional fields
df.isna().sum() # sum of NaN


# In[10]:


df.dropna()

# select columns
df = df[['_id',
         'created_at',
         'full_text',
         'entities', ### hashtag from entities
         'user', ### name from user
         'retweet_count',
         'favorite_count',
         'lang']]

# df.to_csv('climatesolutions.csv', index = False)

