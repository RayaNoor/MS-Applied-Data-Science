#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from os import path
from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator

import matplotlib.pyplot as plt

# pd.set_option("display.max_colwidth", None)
tweets = pd.read_csv('climatetweets.csv')
tweets['full_text'] = tweets['full_text'].str.wrap(100)
tweets.head(5)


# In[2]:


tweetsen = tweets[tweets['lang']=='en']
tweetsen[['full_text']]

len(tweetsen) #1907 english tweets


# In[3]:


# datacamp.com/community/tutorials/wordcloud-python

text = " ".join(review for review in tweetsen.full_text)
print ("There are {} words in the combination of all review.".format(len(text)))


# In[8]:


# datacamp.com/community/tutorials/wordcloud-python

# Create stopword list:
stopwords = set(STOPWORDS)
stopwords.update(["RT", "https", "t", "co", "s", 
                  "climatechange", "globalwarming", "climatechangehoax", "climatechangefraud", "globalwarminghoax", 
                  "climatecrisishoax", "climate", "change", "global", "warming", "amp"])

# Generate a word cloud image
wordcloud = WordCloud(stopwords=stopwords, background_color="white").generate(text)

# Display the generated image:
# the matplotlib way:
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()


# In[9]:


pd.set_option("display.max_colwidth", 0)
topRT = tweets[['full_text', 'retweet_count']].groupby(tweets['full_text']).sum().sort_values(by = 'retweet_count', ascending = False)
topRT


# In[63]:


pd.set_option("display.max_colwidth", 0)
topfave = tweets[['full_text', 'favorite_count']].groupby(tweets['full_text']).sum().sort_values(by = 'favorite_count', 
                                                                                                 ascending = False)
topfave.head(15)[:1]


# In[64]:


tweets['retweet_count'].max()


# In[23]:


tweets['lang'].value_counts()


# In[24]:


lang = tweets.groupby("lang")

plt.figure(figsize=(15,10))
lang.size().sort_values(ascending=False).plot.bar()
plt.xticks(rotation=50)
plt.xlabel("Language")
plt.ylabel("Number of Tweets")
plt.show()


# In[ ]:




