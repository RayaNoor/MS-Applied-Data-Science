#!/usr/bin/env python
# coding: utf-8

# In[5]:


# SEMI-STRUCTURED DATA PROCESSING

# This program reads in JSON formatted data from a MongoDB collection.
# This is in a format that is structured with lines of data representing one Tweet for Twitter.
# This program contains the data as lists of JSON structures, which are just Python dictionaries and lists.

# START MONGODB
# brew services start mongodb-community@4.4

# SCRAPE TWEETS 
# !python run_twitter_simple_search_save.py "#climatechange" 900 climate climatetweets
# !python run_twitter_simple_search_save.py "#globalwarming" 900 climate climatetweets
# !python run_twitter_simple_search_save.py "#ClimateChangeHoax" 900 climate climatetweets
# !python run_twitter_simple_search_save.py "#ClimateChangeFraud" 900 climate climatetweets
# !python run_twitter_simple_search_save.py "#GlobalWarmingHoax" 900 climate climatetweets
# !python run_twitter_simple_search_save.py "#GlobalWarmingHoax" 900 climate climatetweets
# !python run_twitter_simple_search_save.py "#ClimateCrisisHoax" 900 climate climatetweets

# STOP MONGODB
# brew services stop mongodb-community@4.4


# In[6]:


import pymongo
client = pymongo.MongoClient('localhost', 27017)

db = client.climate

db.list_collection_names()


# In[7]:


collection = db.climatetweets

tweets = collection.find()

tweetlist = [tweet for tweet in tweets]
len(tweetlist)


# In[9]:


# Here is a little print function that will help.

def print_tweet_data(tweets):
   for tweet in tweets:
       print('\nDate:', tweet['created_at'])
       print('From:', tweet['user']['name'])
       print('Message:', tweet['full_text'])
       if not tweet['place'] is None:
           print('Place:', tweet['place']['full_name'])

print_tweet_data(tweetlist[:5])


# In[ ]:


# https://docs.mongodb.com/database-tools/mongoexport/#examples


# In[10]:


# My program contains pandas dataframes for processed data.

# This program does some processing to collect data from some of the fields the questions described below, 
# and write a file with the data suitable for answering each question.

import numpy as np
import pandas as pd

df = pd.DataFrame(tweetlist)

# Test for null values and remove optional fields
df.isna().sum() # sum of NaN


# In[13]:


df.dropna()

# select columns
df = df[['_id',
         'created_at',
         'full_text',
         'entities', ### hashtag from entities
         'user', ### name from user
         'retweet_count',
         'favorite_count',
         'lang']]

# df.to_csv('climatetweets.csv', index = False)

